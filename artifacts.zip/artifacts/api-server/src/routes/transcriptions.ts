import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import { z } from "zod";
import { db, transcriptionsTable, type SegmentRow, type ClipSuggestion } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { UpdateTranscriptionBody, UpdateTranscriptionParams } from "@workspace/api-zod";
import { openai, ensureCompatibleFormat } from "@workspace/integrations-openai-ai-server/audio";
import { toFile } from "openai";
import { randomUUID } from "crypto";
import { objectStorageClient, ObjectNotFoundError } from "../lib/objectStorage";
import { spawn } from "child_process";
import { writeFile, unlink } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";

const router: IRouter = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 250 * 1024 * 1024 },
});

const VIDEO_HINTS = ["video/", ".mp4", ".mov", ".webm", ".mkv", ".avi", ".m4v"];

function deriveMediaType(mime: string | undefined, filename: string): "audio" | "video" {
  const lowered = `${mime ?? ""} ${filename.toLowerCase()}`;
  return VIDEO_HINTS.some((hint) => lowered.includes(hint)) ? "video" : "audio";
}

function deriveTitleFromFilename(filename: string): string {
  const base = filename.replace(/\.[^.]+$/, "");
  const cleaned = base.replace(/[_\-]+/g, " ").trim();
  return cleaned.length > 0 ? cleaned : filename;
}

function countWords(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).length;
}

async function getAudioDuration(buffer: Buffer): Promise<number> {
  const inputPath = join(tmpdir(), `duration-${randomUUID()}`);
  try {
    await writeFile(inputPath, buffer);
    return await new Promise<number>((resolve) => {
      const ffprobe = spawn("ffprobe", [
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        inputPath,
      ]);
      let stdout = "";
      ffprobe.stdout.on("data", (d: Buffer) => { stdout += d.toString(); });
      ffprobe.on("close", () => {
        try {
          const info = JSON.parse(stdout);
          const dur = parseFloat(info?.format?.duration ?? "0");
          resolve(isNaN(dur) ? 0 : dur);
        } catch {
          resolve(0);
        }
      });
      ffprobe.on("error", () => resolve(0));
    });
  } finally {
    await unlink(inputPath).catch(() => {});
  }
}

function buildSegmentsFromText(text: string, duration: number): SegmentRow[] {
  // Split on sentence boundaries
  const sentences = text
    .split(/(?<=[.!?。！？])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (sentences.length === 0) {
    return duration > 0
      ? [{ id: 0, start: 0, end: duration, text }]
      : [{ id: 0, start: 0, end: 0, text }];
  }

  const totalWords = sentences.reduce((sum, s) => sum + countWords(s), 0);
  const segments: SegmentRow[] = [];
  let elapsed = 0;

  for (let i = 0; i < sentences.length; i++) {
    const words = countWords(sentences[i]);
    const fraction = totalWords > 0 ? words / totalWords : 1 / sentences.length;
    const segDur = duration * fraction;
    segments.push({
      id: i,
      start: parseFloat(elapsed.toFixed(2)),
      end: parseFloat((elapsed + segDur).toFixed(2)),
      text: sentences[i],
    });
    elapsed += segDur;
  }

  return segments;
}

async function generateClips(
  text: string,
  duration: number,
  language: string
): Promise<ClipSuggestion[]> {
  if (!text.trim() || duration < 5) return [];

  const langHint = language !== "unknown" ? ` The audio is in "${language}".` : "";
  const prompt = `You are a social media clip expert. Given this audio transcript (${Math.round(duration)} seconds total), identify the 5 most engaging and shareable moments that would make great short clips (ideally 20-90 seconds each).${langHint}

Return ONLY a valid JSON array with this exact structure (no markdown, no explanation):
[{"id":0,"start":0,"end":45,"title":"Engaging title","text":"The exact quote from the transcript"},...]

Rules:
- Each clip must be a contiguous segment of the transcript
- start/end are in seconds (floats), must be within 0 and ${duration}
- title is a short, punchy description (max 8 words)
- text is the verbatim transcript text for that segment
- Order clips by how shareable/engaging they are (most engaging first)
- Clips may overlap if the content warrants it

TRANSCRIPT:
${text.slice(0, 6000)}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 2048,
      messages: [{ role: "user", content: prompt }],
    });
    const raw = response.choices[0]?.message?.content ?? "[]";
    const cleaned = raw.trim().replace(/^```json\s*/i, "").replace(/```$/, "").trim();
    const parsed = JSON.parse(cleaned);
    if (!Array.isArray(parsed)) return [];
    return parsed.slice(0, 5).map((c: any, i: number) => ({
      id: i,
      start: Math.max(0, Number(c.start) || 0),
      end: Math.min(duration, Number(c.end) || duration),
      title: String(c.title || "").slice(0, 100),
      text: String(c.text || "").slice(0, 2000),
    }));
  } catch (err) {
    return [];
  }
}

function getPrivateObjectDir(): string {
  const dir = process.env.PRIVATE_OBJECT_DIR ?? "";
  if (!dir) throw new Error("PRIVATE_OBJECT_DIR not set");
  return dir;
}

async function uploadMediaToStorage(
  buffer: Buffer,
  mimeType: string,
  ext: string
): Promise<string> {
  const privateDir = getPrivateObjectDir();
  const objectId = randomUUID();
  const fullGcsPath = `${privateDir}/media/${objectId}.${ext}`;
  const withoutLeadingSlash = fullGcsPath.replace(/^\//, "");
  const slashIdx = withoutLeadingSlash.indexOf("/");
  const bucketName = withoutLeadingSlash.slice(0, slashIdx);
  const objectName = withoutLeadingSlash.slice(slashIdx + 1);
  const bucket = objectStorageClient.bucket(bucketName);
  const file = bucket.file(objectName);
  await file.save(buffer, { contentType: mimeType, resumable: false });
  return `/objects/media/${objectId}.${ext}`;
}

function summarizeRow(row: typeof transcriptionsTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    filename: row.filename,
    mediaType: row.mediaType as "audio" | "video",
    language: row.language,
    duration: row.duration,
    segmentCount: row.segmentCount,
    wordCount: row.wordCount,
    createdAt: row.createdAt.toISOString(),
  };
}

function fullTranscription(row: typeof transcriptionsTable.$inferSelect) {
  return {
    ...summarizeRow(row),
    fullText: row.fullText,
    segments: row.segments,
    mediaObjectPath: row.mediaObjectPath ?? null,
    clips: row.clips ?? null,
  };
}

router.get("/", async (_req, res) => {
  const rows = await db
    .select()
    .from(transcriptionsTable)
    .orderBy(desc(transcriptionsTable.createdAt));
  res.json(rows.map(summarizeRow));
});

router.get("/stats", async (_req, res) => {
  const rows = await db
    .select()
    .from(transcriptionsTable)
    .orderBy(desc(transcriptionsTable.createdAt));
  const totalDurationSeconds = rows.reduce((acc, row) => acc + (row.duration ?? 0), 0);
  const totalWords = rows.reduce((acc, row) => acc + (row.wordCount ?? 0), 0);
  const langCounts = new Map<string, number>();
  for (const row of rows) {
    langCounts.set(row.language, (langCounts.get(row.language) ?? 0) + 1);
  }
  const languages = Array.from(langCounts.entries())
    .map(([language, count]) => ({ language, count }))
    .sort((a, b) => b.count - a.count);
  res.json({
    totalTranscriptions: rows.length,
    totalDurationSeconds,
    totalWords,
    languages,
    recent: rows.slice(0, 5).map(summarizeRow),
  });
});

router.get("/:id/media", async (req, res) => {
  const idResult = z.coerce.number().int().positive().safeParse(req.params.id);
  if (!idResult.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [row] = await db
    .select()
    .from(transcriptionsTable)
    .where(eq(transcriptionsTable.id, idResult.data))
    .limit(1);
  if (!row) { res.status(404).json({ error: "Transcription not found" }); return; }
  if (!row.mediaObjectPath) { res.status(404).json({ error: "No media stored" }); return; }

  const objectPath = row.mediaObjectPath;
  if (!objectPath.startsWith("/objects/")) { res.status(404).json({ error: "Invalid media path" }); return; }

  const privateDir = getPrivateObjectDir();
  const entityId = objectPath.slice("/objects/".length);
  const fullGcsPath = `${privateDir}/${entityId}`.replace(/^\//, "");
  const slashIdx = fullGcsPath.indexOf("/");
  const bucketName = fullGcsPath.slice(0, slashIdx);
  const objectName = fullGcsPath.slice(slashIdx + 1);
  const bucket = objectStorageClient.bucket(bucketName);
  const file = bucket.file(objectName);
  const [exists] = await file.exists();
  if (!exists) { res.status(404).json({ error: "Media file not found in storage" }); return; }

  const [metadata] = await file.getMetadata();
  const contentType = (metadata.contentType as string) || "application/octet-stream";
  const contentLength = metadata.size ? String(metadata.size) : undefined;

  const rangeHeader = req.headers.range;
  if (rangeHeader && contentLength) {
    const size = parseInt(contentLength, 10);
    const [startStr, endStr] = rangeHeader.replace("bytes=", "").split("-");
    const start = parseInt(startStr, 10);
    const end = endStr ? parseInt(endStr, 10) : size - 1;
    res.writeHead(206, {
      "Content-Range": `bytes ${start}-${end}/${size}`,
      "Accept-Ranges": "bytes",
      "Content-Length": end - start + 1,
      "Content-Type": contentType,
    });
    file.createReadStream({ start, end }).pipe(res);
    return;
  }

  res.setHeader("Content-Type", contentType);
  res.setHeader("Accept-Ranges", "bytes");
  if (contentLength) res.setHeader("Content-Length", contentLength);
  res.setHeader("Cache-Control", "private, max-age=3600");
  file.createReadStream().pipe(res);
});

router.get("/:id", async (req, res) => {
  const idResult = z.coerce.number().int().positive().safeParse(req.params.id);
  if (!idResult.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [row] = await db
    .select()
    .from(transcriptionsTable)
    .where(eq(transcriptionsTable.id, idResult.data))
    .limit(1);
  if (!row) { res.status(404).json({ error: "Transcription not found" }); return; }
  res.json(fullTranscription(row));
});

router.patch("/:id", async (req, res) => {
  const params = UpdateTranscriptionParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = UpdateTranscriptionBody.safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: "Invalid body" }); return; }

  const updates: Partial<typeof transcriptionsTable.$inferInsert> = {};
  if (typeof body.data.title === "string" && body.data.title.trim()) {
    updates.title = body.data.title.trim();
  }
  if (Array.isArray(body.data.segments)) {
    const segs: SegmentRow[] = body.data.segments.map((s, idx) => ({
      id: typeof s.id === "number" ? s.id : idx,
      start: Number(s.start),
      end: Number(s.end),
      text: String(s.text ?? ""),
    }));
    const fullText = segs.map((s) => s.text.trim()).filter(Boolean).join(" ");
    updates.segments = segs;
    updates.fullText = fullText;
    updates.segmentCount = segs.length;
    updates.wordCount = countWords(fullText);
  }

  if (Object.keys(updates).length === 0) {
    res.status(400).json({ error: "No fields to update" });
    return;
  }

  const [row] = await db
    .update(transcriptionsTable)
    .set(updates)
    .where(eq(transcriptionsTable.id, params.data.id))
    .returning();
  if (!row) { res.status(404).json({ error: "Transcription not found" }); return; }
  res.json(fullTranscription(row));
});

router.delete("/:id", async (req, res) => {
  const idResult = z.coerce.number().int().positive().safeParse(req.params.id);
  if (!idResult.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const result = await db
    .delete(transcriptionsTable)
    .where(eq(transcriptionsTable.id, idResult.data))
    .returning({ id: transcriptionsTable.id });
  if (result.length === 0) { res.status(404).json({ error: "Transcription not found" }); return; }
  res.status(204).end();
});

router.post("/", upload.single("file"), async (req: Request, res: Response) => {
  const file = req.file;
  if (!file) {
    res.status(400).json({ error: "No file uploaded. Field name must be 'file'." });
    return;
  }

  const language =
    typeof req.body?.language === "string" && req.body.language.trim()
      ? req.body.language.trim()
      : undefined;

  try {
    const { buffer, format } = await ensureCompatibleFormat(file.buffer);
    const filename = file.originalname || `upload.${format}`;

    // Get actual duration via ffprobe on the original buffer
    const duration = await getAudioDuration(file.buffer);

    // Transcribe with gpt-4o-mini-transcribe (only "json" format supported)
    const uploadFile = await toFile(buffer, `audio.${format}`);
    const transcriptionResp = await (openai.audio.transcriptions.create as any)({
      file: uploadFile,
      model: "gpt-4o-mini-transcribe",
      response_format: "json",
      ...(language ? { language } : {}),
    });

    const fullText: string =
      typeof transcriptionResp?.text === "string"
        ? transcriptionResp.text.trim()
        : "";

    const detectedLanguage: string =
      typeof transcriptionResp?.language === "string" && transcriptionResp.language.trim()
        ? transcriptionResp.language
        : language ?? "unknown";

    // Build timestamped segments from plain text + duration
    const effectiveDuration = duration > 0 ? duration : 0;
    const segments = buildSegmentsFromText(fullText, effectiveDuration);

    // Generate AI clip suggestions in parallel with media upload
    const mediaType = deriveMediaType(file.mimetype, filename);
    const title = deriveTitleFromFilename(filename);

    const [clips, mediaObjectPath] = await Promise.all([
      generateClips(fullText, effectiveDuration, detectedLanguage).catch(() => null),
      uploadMediaToStorage(file.buffer, file.mimetype || `${mediaType}/${format}`, format)
        .catch((err) => {
          req.log.warn({ err }, "Media upload to storage failed; transcription will proceed without playback");
          return null;
        }),
    ]);

    const [row] = await db
      .insert(transcriptionsTable)
      .values({
        title,
        filename,
        mediaType,
        language: detectedLanguage,
        duration: effectiveDuration,
        segmentCount: segments.length,
        wordCount: countWords(fullText),
        fullText,
        segments,
        mediaObjectPath,
        clips,
      })
      .returning();

    res.status(201).json(fullTranscription(row));
  } catch (err) {
    req.log.error({ err }, "Failed to transcribe upload");
    const message =
      err instanceof Error ? err.message : "Failed to transcribe the uploaded file.";
    res.status(500).json({ error: message });
  }
});

export default router;
