import { useRef, useState, useCallback, forwardRef, useImperativeHandle } from "react";
import { Play, Pause, Volume2, VolumeX } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { formatTimeMS } from "@/lib/export-utils";

type Segment = { id: number; start: number; end: number; text: string };

export interface MediaPlayerHandle {
  seekTo: (time: number) => void;
}

interface MediaPlayerProps {
  transcriptionId: number;
  mediaType: "audio" | "video";
  segments: Segment[];
  activeSegmentIndex: number | null;
  onTimeUpdate: (time: number) => void;
  onSegmentClick: (time: number) => void;
}

export const MediaPlayer = forwardRef<MediaPlayerHandle, MediaPlayerProps>(
  function MediaPlayer(
    { transcriptionId, mediaType, segments, activeSegmentIndex, onTimeUpdate, onSegmentClick: _ },
    ref
  ) {
    const mediaRef = useRef<HTMLVideoElement | HTMLAudioElement | null>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [volume, setVolume] = useState(1);
    const [isMuted, setIsMuted] = useState(false);
    const [error, setError] = useState(false);

    const mediaUrl = `/api/transcriptions/${transcriptionId}/media`;

    useImperativeHandle(ref, () => ({
      seekTo(time: number) {
        const el = mediaRef.current;
        if (!el) return;
        el.currentTime = time;
        setCurrentTime(time);
        onTimeUpdate(time);
        el.play().catch(() => {});
      },
    }));

    const handleTimeUpdate = useCallback(() => {
      const el = mediaRef.current;
      if (!el) return;
      setCurrentTime(el.currentTime);
      onTimeUpdate(el.currentTime);
    }, [onTimeUpdate]);

    const handleLoadedMetadata = useCallback(() => {
      const el = mediaRef.current;
      if (!el) return;
      setDuration(el.duration);
    }, []);

    const handlePlayPause = () => {
      const el = mediaRef.current;
      if (!el) return;
      if (isPlaying) el.pause();
      else el.play();
    };

    const handleSeek = (value: number[]) => {
      const el = mediaRef.current;
      if (!el) return;
      el.currentTime = value[0];
      setCurrentTime(value[0]);
      onTimeUpdate(value[0]);
    };

    const handleVolumeChange = (value: number[]) => {
      const el = mediaRef.current;
      if (!el) return;
      const v = value[0];
      el.volume = v;
      setVolume(v);
      setIsMuted(v === 0);
    };

    const handleMuteToggle = () => {
      const el = mediaRef.current;
      if (!el) return;
      const newMuted = !isMuted;
      el.muted = newMuted;
      setIsMuted(newMuted);
    };

    const handleError = () => setError(true);

    const activeSegment = activeSegmentIndex !== null ? segments[activeSegmentIndex] : null;

    if (error) return null;

    return (
      <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
        {mediaType === "video" && (
          <div className="relative bg-black aspect-video">
            <video
              ref={mediaRef as React.RefObject<HTMLVideoElement>}
              src={mediaUrl}
              className="w-full h-full object-contain"
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onEnded={() => setIsPlaying(false)}
              onError={handleError}
              preload="metadata"
            />
            {activeSegment && (
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-full max-w-[90%] px-4">
                <div className="bg-black/80 text-white text-sm text-center px-4 py-2 rounded-lg leading-snug backdrop-blur-sm">
                  {activeSegment.text}
                </div>
              </div>
            )}
          </div>
        )}

        {mediaType === "audio" && (
          <audio
            ref={mediaRef as React.RefObject<HTMLAudioElement>}
            src={mediaUrl}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => setIsPlaying(false)}
            onError={handleError}
            preload="metadata"
            className="hidden"
          />
        )}

        {mediaType === "audio" && activeSegment && (
          <div className="px-5 pt-5 pb-2">
            <div className="rounded-lg bg-muted/50 border px-4 py-3 text-sm text-center text-foreground min-h-[48px] flex items-center justify-center leading-snug">
              {activeSegment.text}
            </div>
          </div>
        )}

        <div className="px-5 py-4 space-y-3">
          <div className="flex items-center gap-2 text-xs tabular-nums text-muted-foreground font-mono">
            <span>{formatTimeMS(currentTime, ".")}</span>
            <Slider
              min={0}
              max={duration || 1}
              step={0.05}
              value={[currentTime]}
              onValueChange={handleSeek}
              className="flex-1"
            />
            <span>{formatTimeMS(duration, ".")}</span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={handlePlayPause} className="h-9 w-9">
                {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={handleMuteToggle} className="h-8 w-8">
                {isMuted || volume === 0
                  ? <VolumeX className="h-3.5 w-3.5" />
                  : <Volume2 className="h-3.5 w-3.5" />}
              </Button>
              <Slider
                min={0}
                max={1}
                step={0.02}
                value={[isMuted ? 0 : volume]}
                onValueChange={handleVolumeChange}
                className="w-20"
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
);
