import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";

const LANGS = ["en", "th"] as const;

export function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const current = i18n.language as "en" | "th";

  const next = current === "en" ? "th" : "en";
  const labels: Record<"en" | "th", string> = { en: "EN", th: "ไทย" };

  return (
    <Button
      variant="ghost"
      size="sm"
      className="h-8 px-3 text-sm font-medium text-muted-foreground hover:text-foreground"
      onClick={() => i18n.changeLanguage(next)}
    >
      {labels[next]}
    </Button>
  );
}
