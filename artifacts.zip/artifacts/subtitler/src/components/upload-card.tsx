import { useState, useRef, DragEvent, ChangeEvent } from "react";
import { useLocation } from "wouter";
import { UploadCloud, FileAudio, Loader2, AlertCircle } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useCreateTranscription, getListTranscriptionsQueryKey, getGetTranscriptionStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";

const MAX_FILE_SIZE = 200 * 1024 * 1024;

const LANGUAGES = [
  { value: "en", label: "English" },
  { value: "th", label: "Thai" },
  { value: "es", label: "Spanish" },
  { value: "fr", label: "French" },
  { value: "de", label: "German" },
  { value: "it", label: "Italian" },
  { value: "pt", label: "Portuguese" },
  { value: "nl", label: "Dutch" },
  { value: "ja", label: "Japanese" },
  { value: "ko", label: "Korean" },
  { value: "zh", label: "Chinese" },
  { value: "hi", label: "Hindi" },
  { value: "ar", label: "Arabic" },
  { value: "ru", label: "Russian" },
  { value: "tr", label: "Turkish" },
];

export function UploadCard() {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createTranscription = useCreateTranscription();

  const [file, setFile] = useState<File | null>(null);
  const [language, setLanguage] = useState<string>("auto");
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const validateAndSetFile = (selectedFile: File) => {
    setError(null);
    if (!selectedFile.type.startsWith("audio/") && !selectedFile.type.startsWith("video/")) {
      setError(t("upload.errorInvalidType"));
      setFile(null);
      return;
    }
    if (selectedFile.size > MAX_FILE_SIZE) {
      setError(t("upload.errorTooLarge"));
      setFile(null);
      return;
    }
    setFile(selectedFile);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setError(null);
    try {
      const langValue = language === "auto" ? undefined : language;
      const transcription = await createTranscription.mutateAsync({
        data: { file, language: langValue },
      });
      queryClient.invalidateQueries({ queryKey: getListTranscriptionsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetTranscriptionStatsQueryKey() });
      setLocation(`/transcriptions/${transcription.id}`);
    } catch (err: any) {
      setError(err?.message || t("upload.errorGeneric"));
    }
  };

  if (createTranscription.isPending) {
    return (
      <Card className="w-full">
        <CardContent className="flex flex-col items-center justify-center min-h-[300px] text-center p-6 space-y-6">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping"></div>
            <div className="relative bg-primary/10 p-4 rounded-full">
              <Loader2 className="w-10 h-10 text-primary animate-spin" />
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-semibold">{t("upload.transcribing")}</h3>
            <p className="text-muted-foreground text-sm max-w-sm mx-auto">
              {t("upload.transcribingHint")}
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{t("upload.cardTitle")}</CardTitle>
        <CardDescription>{t("upload.cardDesc")}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div
          className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer ${dragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-primary/50"} ${file ? "bg-primary/5 border-primary/50" : ""}`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => !file && inputRef.current?.click()}
          role="button"
          tabIndex={0}
        >
          <input
            ref={inputRef}
            type="file"
            className="hidden"
            accept="audio/*,video/*"
            onChange={handleChange}
          />
          {file ? (
            <div className="flex flex-col items-center gap-3">
              <div className="bg-primary/10 p-3 rounded-full">
                <FileAudio className="w-8 h-8 text-primary" />
              </div>
              <div>
                <p className="font-medium">{file.name}</p>
                <p className="text-sm text-muted-foreground">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
              </div>
              <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); setFile(null); }}>
                {t("upload.removeFile")}
              </Button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3">
              <div className="bg-muted p-4 rounded-full">
                <UploadCloud className="w-8 h-8 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium">{t("upload.dropzone")}</p>
                <p className="text-sm text-muted-foreground">{t("upload.dropzoneHint")}</p>
              </div>
            </div>
          )}
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>{t("upload.errorTitle")}</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid gap-2">
          <Label htmlFor="language">{t("upload.languageLabel")}</Label>
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger id="language">
              <SelectValue placeholder={t("upload.autoDetect")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">{t("upload.autoDetect")}</SelectItem>
              {LANGUAGES.map((lang) => (
                <SelectItem key={lang.value} value={lang.value}>{lang.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">{t("upload.languageHint")}</p>
        </div>
      </CardContent>
      <CardFooter className="flex justify-end border-t bg-muted/20 px-6 py-4">
        <Button onClick={handleUpload} disabled={!file} className="w-full sm:w-auto">
          {t("upload.generate")}
        </Button>
      </CardFooter>
    </Card>
  );
}
