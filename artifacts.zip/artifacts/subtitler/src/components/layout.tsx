import { ReactNode } from "react";
import { Link } from "wouter";
import { Scissors } from "lucide-react";
import { useTranslation } from "react-i18next";
import { LanguageSwitcher } from "@/components/language-switcher";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { t } = useTranslation();
  return (
    <div className="min-h-[100dvh] flex flex-col w-full">
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
        <div className="container flex h-14 items-center justify-between mx-auto px-4 max-w-5xl">
          <Link href="/" className="flex items-center gap-2 font-semibold text-primary transition-opacity hover:opacity-80">
            <Scissors className="h-5 w-5" />
            <span>{t("appName")}</span>
          </Link>
          <LanguageSwitcher />
        </div>
      </header>
      <main className="flex-1 w-full mx-auto px-4 max-w-5xl py-8">
        {children}
      </main>
    </div>
  );
}
