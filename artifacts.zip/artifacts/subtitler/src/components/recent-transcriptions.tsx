import { useListTranscriptions, useGetTranscriptionStats } from "@workspace/api-client-react";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { th as dateFnsTh } from "date-fns/locale";
import { useTranslation } from "react-i18next";
import { FileAudio, FileVideo, Clock, FileText, Hash, Globe2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

function useLocale() {
  const { i18n } = useTranslation();
  return i18n.language === "th" ? dateFnsTh : undefined;
}

export function StatsCard() {
  const { t } = useTranslation();
  const { data: stats, isLoading } = useGetTranscriptionStats();

  if (isLoading) {
    return <Skeleton className="w-full h-[120px] rounded-xl" />;
  }

  if (!stats) return null;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <FileText className="w-4 h-4" />
            <span className="text-sm font-medium">{t("stats.totalFiles")}</span>
          </div>
          <div className="text-2xl font-bold">{stats.totalTranscriptions}</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Clock className="w-4 h-4" />
            <span className="text-sm font-medium">{t("stats.minutesProcessed")}</span>
          </div>
          <div className="text-2xl font-bold">{Math.round(stats.totalDurationSeconds / 60)}</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Hash className="w-4 h-4" />
            <span className="text-sm font-medium">{t("stats.totalWords")}</span>
          </div>
          <div className="text-2xl font-bold">{stats.totalWords.toLocaleString()}</div>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Globe2 className="w-4 h-4" />
            <span className="text-sm font-medium">{t("stats.languages")}</span>
          </div>
          <div className="text-2xl font-bold">{stats.languages.length}</div>
        </CardContent>
      </Card>
    </div>
  );
}

export function RecentTranscriptions() {
  const { t } = useTranslation();
  const locale = useLocale();
  const { data: transcriptions, isLoading } = useListTranscriptions();

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="w-full h-24 rounded-xl" />
        ))}
      </div>
    );
  }

  if (!transcriptions || transcriptions.length === 0) {
    return (
      <Card className="bg-muted/30 border-dashed">
        <CardContent className="flex flex-col items-center justify-center p-12 text-center space-y-3">
          <div className="bg-muted p-4 rounded-full">
            <FileText className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium">{t("recent.empty")}</h3>
          <p className="text-sm text-muted-foreground max-w-sm">{t("recent.emptyHint")}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid gap-3">
        {transcriptions.map((t_item) => (
          <Link key={t_item.id} href={`/transcriptions/${t_item.id}`}>
            <Card className="group cursor-pointer transition-all hover:border-primary/50 hover:shadow-sm">
              <CardContent className="p-4 sm:p-5 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <div className="bg-primary/10 p-3 rounded-lg shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  {t_item.mediaType === "video" ? <FileVideo className="w-6 h-6" /> : <FileAudio className="w-6 h-6" />}
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <h4 className="font-semibold text-base truncate" title={t_item.title}>
                    {t_item.title}
                  </h4>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                    <span className="truncate">{t_item.filename}</span>
                    <span className="hidden sm:inline">&bull;</span>
                    <span>{formatDistanceToNow(new Date(t_item.createdAt), { addSuffix: true, locale })}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0 sm:ml-auto">
                  <Badge variant="secondary" className="capitalize">{t_item.language}</Badge>
                  <Badge variant="outline">{Math.round(t_item.duration)}s</Badge>
                  <Badge variant="outline">{t_item.wordCount} {t("recent.words")}</Badge>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
