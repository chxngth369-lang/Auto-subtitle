import type { Segment } from "@workspace/api-client-react";

export function formatTime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function formatTimeMS(seconds: number, separator: string = ","): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  
  return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}${separator}${ms.toString().padStart(3, "0")}`;
}

export function generateSRT(segments: Segment[]): string {
  return segments.map((seg, idx) => {
    const start = formatTimeMS(seg.start, ",");
    const end = formatTimeMS(seg.end, ",");
    return `${idx + 1}\n${start} --> ${end}\n${seg.text}\n`;
  }).join("\n");
}

export function generateVTT(segments: Segment[]): string {
  const body = segments.map((seg, idx) => {
    const start = formatTimeMS(seg.start, ".");
    const end = formatTimeMS(seg.end, ".");
    return `${idx + 1}\n${start} --> ${end}\n${seg.text}\n`;
  }).join("\n");
  
  return `WEBVTT\n\n${body}`;
}

export function generateTXT(segments: Segment[]): string {
  return segments.map(s => s.text).join(" ");
}

export function downloadStringAsFile(content: string, filename: string, mimeType: string = "text/plain") {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
