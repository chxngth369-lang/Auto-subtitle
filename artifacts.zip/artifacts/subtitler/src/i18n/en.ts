const en = {
  appName: "Auto Subtitled",

  home: {
    hero: "Turn speech into text,",
    heroAccent: "magically.",
    heroSub:
      "Upload any audio or video file and get accurate, perfectly timed subtitles in seconds. Export to SRT, VTT, or plain text.",
    statsTitle: "Your Studio Stats",
    recentTitle: "Recent Transcriptions",
  },

  upload: {
    cardTitle: "New Transcription",
    cardDesc: "Upload an audio or video file to generate subtitles.",
    dropzone: "Click to upload or drag and drop",
    dropzoneHint: "Audio or Video (max. 200MB)",
    removeFile: "Remove file",
    languageLabel: "Audio Language",
    languageHint:
      "Selecting the correct language can improve accuracy, though auto-detect works well for most cases.",
    autoDetect: "Auto-detect",
    generate: "Generate Subtitles",
    transcribing: "Transcribing your file...",
    transcribingHint:
      "This might take a moment depending on the file size and duration. Feel free to wait here while we process the audio.",
    errorTitle: "Error",
    errorInvalidType: "Please select a valid audio or video file.",
    errorTooLarge: "File exceeds the 200MB limit.",
    errorGeneric: "An error occurred during upload. Please try again.",
  },

  stats: {
    totalFiles: "Total Files",
    minutesProcessed: "Minutes Processed",
    totalWords: "Total Words",
    languages: "Languages",
  },

  recent: {
    empty: "No transcriptions yet",
    emptyHint:
      "Upload your first audio or video file above to generate accurate subtitles.",
    words: "words",
  },

  transcription: {
    backHome: "Home",
    subtitleEditor: "Subtitle Editor",
    autoSaveHint: "Changes save automatically",
    seekHint: "Click a segment timestamp to jump to it",
    saving: "Saving...",
    saved: "Saved",
    copy: "Copy",
    copied: "Copied",
    deleteTitle: "Delete transcription?",
    deleteDesc:
      "This action cannot be undone. This will permanently delete the transcription and all its segments.",
    deleteCancel: "Cancel",
    deleteConfirm: "Delete",
    notFound: "Transcription not found",
    backButton: "Back to Home",
    errorSaveTitle: "Failed to save",
    errorSaveDesc: "Your changes could not be saved. Please try again.",
    errorDelete: "Failed to delete transcription.",
    deleted: "Transcription deleted",
    copied2Clipboard: "Copied to clipboard",
    noSegments: "No segments found in this transcription.",
    noMedia: "No media stored for this transcription.",
    words: "words",
    segments: "segments",
    to: "to",
  },

  clips: {
    sectionTitle: "AI Clips",
    sectionDesc: "The most engaging moments, picked by AI",
    noClips: "No clips were generated for this transcription.",
    playClip: "Play",
    copyClip: "Copy quote",
    copiedClip: "Copied!",
    duration: "sec",
  },

  lang: {
    en: "English",
    th: "ภาษาไทย",
  },
} as const;

export default en;
