import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import en from "./en";
import th from "./th";

const STORAGE_KEY = "auto-subtitled-lang";

const savedLang = typeof localStorage !== "undefined"
  ? (localStorage.getItem(STORAGE_KEY) ?? "en")
  : "en";

i18n.use(initReactI18next).init({
  resources: {
    en: { translation: en },
    th: { translation: th },
  },
  lng: savedLang,
  fallbackLng: "en",
  interpolation: { escapeValue: false },
});

i18n.on("languageChanged", (lng) => {
  if (typeof localStorage !== "undefined") {
    localStorage.setItem(STORAGE_KEY, lng);
  }
});

export default i18n;
