import { useEffect, useState, useRef, useCallback } from "react";
import { useLocation, useParams } from "wouter";
import { useTranslation } from "react-i18next";
import { Layout } from "@/components/layout";
import {
  useGetTranscription,
  useUpdateTranscription,
  useDeleteTranscription,
  getGetTranscriptionQueryKey,
  getListTranscriptionsQueryKey,
  getGetTranscriptionStatsQueryKey,
} from "@workspace/api-client-react";
import type { ClipSuggestion } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft,
  Trash2,
  Copy,
  Check,
  CheckCircle2,
  Loader2,
  Play,
  Scissors,
  Clock,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  formatTime,
  formatTimeMS,
  generateSRT,
  generateVTT,
  generateTXT,
  downloadStringAsFile,
} from "@/lib/export-utils";
import { MediaPlayer, type MediaPlayerHandle } from "@/components/media-player";

function ClipCard({
  clip,
  hasMedia,
  onPlay,
}: {
  clip: ClipSuggestion;
  hasMedia: boolean;
  onPlay: (start: number) => void;
}) {
  const { t } = useTranslation();
  const [copied, setCopied] = useState(false);
  const clipDuration = Math.round(clip.end - clip.start);

  const handleCopy = () => {
    navigator.clipboard.writeText(clip.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="group relative rounded-xl border bg-card overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none" />
      <div className="p-5 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1 flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <Scissors className="h-3.5 w-3.5 text-primary shrink-0" />
              <span className="text-xs font-semibold text-primary uppercase tracking-wide truncate">
                {clip.title}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span>
                {formatTime(clip.start)} – {formatTime(clip.end)}
              </span>
              <span className="text-muted-foreground/50">·</span>
              <span>
                {clipDuration}s
              </span>
            </div>
          </div>
        </div>

        <blockquote className="text-sm leading-relaxed text-foreground border-l-2 border-primary/40 pl-3 italic">
          "{clip.text}"
        </blockquote>

        <div className="flex items-center gap-2 pt-1">
          {hasMedia && (
            <Button
              size="sm"
              variant="default"
              className="h-8 gap-1.5 text-xs"
              onClick={() => onPlay(clip.start)}
            >
              <Play className="h-3 w-3" />
              {t("clips.playClip")}
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            className="h-8 gap-1.5 text-xs"
            onClick={handleCopy}
          >
            {copied ? (
              <><Check className="h-3 w-3 text-green-600" />{t("clips.copiedClip")}</>
            ) : (
              <><Copy className="h-3 w-3" />{t("clips.copyClip")}</>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

function countWords(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).length;
}

export default function TranscriptionDetail() {
  const { id } = useParams();
  const transcriptionId = parseInt(id || "0", 10);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { t } = useTranslation();

  const { data: transcription, isLoading, isError } = useGetTranscription(transcriptionId);
  const updateTranscription = useUpdateTranscription();
  const deleteTranscription = useDeleteTranscription();

  const [title, setTitle] = useState("");
  const [segments, setSegments] = useState<NonNullable<typeof transcription>["segments"]>([]);
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved">("idle");
  const [copied, setCopied] = useState(false);
  const [activeSegmentIndex, setActiveSegmentIndex] = useState<number | null>(null);

  const mediaPlayerRef = useRef<MediaPlayerHandle | null>(null);
  const segmentRefs = useRef<(HTMLDivElement | null)[]>([]);
  const initializedForId = useRef<number | null>(null);
  const mutateFnRef = useRef(updateTranscription.mutate);
  mutateFnRef.current = updateTranscription.mutate;

  useEffect(() => {
    if (transcription && initializedForId.current !== transcription.id) {
      initializedForId.current = transcription.id;
      setTitle(transcription.title);
      setSegments(transcription.segments || []);
    } else if (transcription && transcription.segments && saveStatus === "idle") {
      setSegments(transcription.segments);
    }
  }, [transcription, saveStatus]);

  const handleTimeUpdate = useCallback(
    (time: number) => {
      const segs = segments;
      let found: number | null = null;
      for (let i = 0; i < segs.length; i++) {
        if (time >= segs[i].start && time < segs[i].end) {
          found = i;
          break;
        }
      }
      setActiveSegmentIndex((prev) => {
        if (prev !== found) {
          if (found !== null) {
            segmentRefs.current[found]?.scrollIntoView({ behavior: "smooth", block: "nearest" });
          }
          return found;
        }
        return prev;
      });
    },
    [segments]
  );

  const handleClipPlay = useCallback((start: number) => {
    mediaPlayerRef.current?.seekTo(start);
  }, []);

  const handleTitleBlur = () => {
    if (title !== transcription?.title) {
      saveChanges({ title });
    }
  };

  const handleSegmentChange = (index: number, newText: string) => {
    const newSegments = [...segments];
    newSegments[index] = { ...newSegments[index], text: newText };
    setSegments(newSegments);
  };

  const handleSegmentBlur = (index: number) => {
    const originalText = transcription?.segments[index]?.text;
    const newText = segments[index].text;
    if (originalText !== newText) {
      saveChanges({ segments });
    }
  };

  const saveChanges = useCallback(
    (data: { title?: string; segments?: typeof segments }) => {
      setSaveStatus("saving");
      mutateFnRef.current(
        { id: transcriptionId, data },
        {
          onSuccess: (updatedData) => {
            setSaveStatus("saved");
            setTimeout(() => setSaveStatus("idle"), 2000);
            queryClient.setQueryData(
              getGetTranscriptionQueryKey(transcriptionId),
              (old: any) => (old ? { ...old, ...updatedData } : old)
            );
          },
          onError: () => {
            setSaveStatus("idle");
            toast({
              title: t("transcription.errorSaveTitle"),
              description: t("transcription.errorSaveDesc"),
              variant: "destructive",
            });
          },
        }
      );
    },
    [transcriptionId, queryClient, toast, t]
  );

  const handleDelete = async () => {
    try {
      await deleteTranscription.mutateAsync({ id: transcriptionId });
      queryClient.invalidateQueries({ queryKey: getListTranscriptionsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetTranscriptionStatsQueryKey() });
      toast({ title: t("transcription.deleted") });
      setLocation("/");
    } catch {
      toast({
        title: t("transcription.errorSaveTitle"),
        description: t("transcription.errorDelete"),
        variant: "destructive",
      });
    }
  };

  const handleCopyTranscript = () => {
    if (!transcription) return;
    navigator.clipboard.writeText(generateTXT(segments));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: t("transcription.copied2Clipboard") });
  };

  const handleExport = (format: "srt" | "vtt" | "txt") => {
    if (!transcription) return;
    const filename = `${transcription.filename.split(".")[0] || "transcript"}.${format}`;
    let content = "";
    switch (format) {
      case "srt": content = generateSRT(segments); break;
      case "vtt": content = generateVTT(segments); break;
      case "txt": content = generateTXT(segments); break;
    }
    downloadStringAsFile(content, filename, format === "txt" ? "text/plain" : "text/vtt");
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <Skeleton className="w-32 h-10" />
          <div className="space-y-4">
            <Skeleton className="w-full max-w-md h-12" />
            <div className="flex gap-2">
              <Skeleton className="w-16 h-6" />
              <Skeleton className="w-20 h-6" />
              <Skeleton className="w-24 h-6" />
            </div>
          </div>
          <Skeleton className="w-full h-48 rounded-xl" />
          <div className="space-y-4 mt-8">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="w-full h-24 rounded-lg" />
            ))}
          </div>
        </div>
      </Layout>
    );
  }

  if (isError || !transcription) {
    return (
      <Layout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold mb-4">{t("transcription.notFound")}</h2>
          <Button onClick={() => setLocation("/")} variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" /> {t("transcription.backButton")}
          </Button>
        </div>
      </Layout>
    );
  }

  const hasMedia = !!transcription.mediaObjectPath;
  const clips: ClipSuggestion[] = transcription.clips ?? [];

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
          <button
            onClick={() => setLocation("/")}
            className="flex items-center hover:text-foreground transition-colors"
          >
            <ArrowLeft className="mr-1 h-4 w-4" /> {t("transcription.backHome")}
          </button>
          <span>/</span>
          <span>{transcription.filename}</span>
        </div>

        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-4 flex-1">
            <div className="flex items-center gap-3">
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                onBlur={handleTitleBlur}
                className="text-3xl font-bold border-transparent bg-transparent hover:border-input focus-visible:border-input focus-visible:ring-1 px-0 h-auto py-1 w-full max-w-xl"
              />
              {saveStatus === "saving" && (
                <span className="text-xs text-muted-foreground animate-pulse flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" /> {t("transcription.saving")}
                </span>
              )}
              {saveStatus === "saved" && (
                <span className="text-xs text-green-600 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> {t("transcription.saved")}
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Badge variant="secondary" className="capitalize">{transcription.mediaType}</Badge>
              <Badge variant="outline" className="capitalize">{transcription.language}</Badge>
              <Badge variant="outline">{formatTime(transcription.duration)}</Badge>
              <Badge variant="outline">{transcription.wordCount} {t("transcription.words")}</Badge>
              <Badge variant="outline">{transcription.segmentCount} {t("transcription.segments")}</Badge>
              {clips.length > 0 && (
                <Badge variant="outline" className="text-primary border-primary/40 bg-primary/5">
                  <Scissors className="h-3 w-3 mr-1" />
                  {clips.length} clips
                </Badge>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <Button variant="outline" size="sm" onClick={handleCopyTranscript}>
              {copied
                ? <><Check className="mr-2 h-4 w-4 text-green-600" />{t("transcription.copied")}</>
                : <><Copy className="mr-2 h-4 w-4" />{t("transcription.copy")}</>
              }
            </Button>
            <div className="flex items-center gap-1 bg-muted p-1 rounded-md">
              <Button variant="secondary" size="sm" className="h-8" onClick={() => handleExport("srt")}>SRT</Button>
              <Button variant="secondary" size="sm" className="h-8" onClick={() => handleExport("vtt")}>VTT</Button>
              <Button variant="secondary" size="sm" className="h-8" onClick={() => handleExport("txt")}>TXT</Button>
            </div>

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" size="icon" className="ml-2">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>{t("transcription.deleteTitle")}</AlertDialogTitle>
                  <AlertDialogDescription>{t("transcription.deleteDesc")}</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>{t("transcription.deleteCancel")}</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDelete}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    {t("transcription.deleteConfirm")}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        {hasMedia && (
          <MediaPlayer
            ref={mediaPlayerRef}
            transcriptionId={transcriptionId}
            mediaType={transcription.mediaType as "audio" | "video"}
            segments={segments}
            activeSegmentIndex={activeSegmentIndex}
            onTimeUpdate={handleTimeUpdate}
            onSegmentClick={() => {}}
          />
        )}

        {/* AI Clips Section */}
        {clips.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold flex items-center gap-2">
                  <Scissors className="h-4 w-4 text-primary" />
                  {t("clips.sectionTitle")}
                </h3>
                <p className="text-sm text-muted-foreground mt-0.5">{t("clips.sectionDesc")}</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {clips.map((clip) => (
                <ClipCard
                  key={clip.id}
                  clip={clip}
                  hasMedia={hasMedia}
                  onPlay={handleClipPlay}
                />
              ))}
            </div>
          </div>
        )}

        <div className="border rounded-xl bg-card overflow-hidden shadow-sm">
          <div className="p-4 border-b bg-muted/30 flex items-center justify-between">
            <h3 className="font-semibold">{t("transcription.subtitleEditor")}</h3>
            <span className="text-xs text-muted-foreground">
              {hasMedia ? t("transcription.seekHint") : t("transcription.autoSaveHint")}
            </span>
          </div>

          <div className="divide-y max-h-[600px] overflow-y-auto">
            {segments.map((segment, index) => {
              const isActive = activeSegmentIndex === index;
              return (
                <div
                  key={segment.id}
                  ref={(el) => { segmentRefs.current[index] = el; }}
                  className={`p-4 flex gap-4 group transition-colors ${isActive ? "bg-primary/5 border-l-2 border-l-primary" : "hover:bg-muted/10"}`}
                >
                  <div className="shrink-0 w-24 tabular-nums text-xs font-mono space-y-1 pt-2">
                    <div className={`transition-colors ${isActive ? "text-primary font-semibold" : "text-muted-foreground"}`}>
                      {formatTimeMS(segment.start, ".")}
                    </div>
                    <div className="text-muted-foreground/40">{t("transcription.to")}</div>
                    <div className={`transition-colors ${isActive ? "text-primary font-semibold" : "text-muted-foreground"}`}>
                      {formatTimeMS(segment.end, ".")}
                    </div>
                  </div>
                  <div className="flex-1">
                    <Textarea
                      value={segment.text}
                      onChange={(e) => handleSegmentChange(index, e.target.value)}
                      onBlur={() => handleSegmentBlur(index)}
                      className={`min-h-[60px] resize-none border-transparent bg-transparent hover:border-input focus-visible:border-input focus-visible:ring-1 focus-visible:bg-background transition-colors ${isActive ? "text-foreground" : ""}`}
                    />
                  </div>
                </div>
              );
            })}

            {segments.length === 0 && (
              <div className="p-8 text-center text-muted-foreground">
                {t("transcription.noSegments")}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
