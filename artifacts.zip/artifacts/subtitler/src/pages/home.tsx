import { useTranslation } from "react-i18next";
import { Layout } from "@/components/layout";
import { UploadCard } from "@/components/upload-card";
import { RecentTranscriptions, StatsCard } from "@/components/recent-transcriptions";

export default function Home() {
  const { t } = useTranslation();
  return (
    <Layout>
      <div className="space-y-12">
        <section className="space-y-4">
          <div className="text-center max-w-2xl mx-auto space-y-4 mb-10">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-foreground">
              {t("home.hero")} <span className="text-primary">{t("home.heroAccent")}</span>
            </h1>
            <p className="text-lg text-muted-foreground">
              {t("home.heroSub")}
            </p>
          </div>
          <div className="max-w-2xl mx-auto">
            <UploadCard />
          </div>
        </section>

        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold tracking-tight">{t("home.statsTitle")}</h2>
          </div>
          <StatsCard />
        </section>

        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold tracking-tight">{t("home.recentTitle")}</h2>
          </div>
          <RecentTranscriptions />
        </section>
      </div>
    </Layout>
  );
}
